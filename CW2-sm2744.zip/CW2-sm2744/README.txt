Coursework 2 - Sam Molyneux

Question 1:
	Maximum number of names: 8192
	Enter file path as arguement
	Outputs sorted names to the same text file

Question 2:
	Maximum number of names: 8192
	Maximum number of letters in a name: 64
	Enter file path as arguement
	Outputs sorted names to the same text file
Question 3:
	Maximum number of names: 8192
	Maximum number of letters in a name: 64
	Enter file path as arguement
	Tests are run automatically
		Ensure "ALONSO" is in input file
		Ensure "TEST" is not in input file
		Alternatively manually change the Strings used to test
	Outputs displayed on command line (1 represents true, 0 represents false)
Question 4:
	Maximum number of words: 8192
	Enter file path as arguement
	Interact with program via interface
		Output to file outputs to the source file
Question 5:
	Maximum length of undredacted text: 8192 characters
	Maximum number of redacted words: 100 characters
	Maximum length of redacted words: 20 characters
	Enter file path to redact from as first arguement
	Enter file path with words to redact as second arguement
	Words are redacted and output is written to original text file and command line
Question 6:
	Not Attempted
Question 7:
	Maximum length of plain text: 8192 characters
	Enter file path of plain text as first arguement
	Enter string to use as key as second arguement
	encrypted text is written to the plain text file and the command line
Question 8:
	Input X as a parameter 
	Where the result is the sum of diagonals of an X by X spiral




